filename P6F15715 list;

 %put NOTE- ;
 %put NOTE: Data for package mergeNSV, version 1.0.0, license MIT; 
 %put NOTE: *** %superq(packageTitle) ***; 
 %put NOTE- Generated: 2026-10-27T18:13:48; 
 %put NOTE- Author(s): %superq(packageAuthor); 
 %put NOTE- Maintainer(s): %superq(packageMaintainer); 
 %put NOTE- ;
 %put NOTE- Write %nrstr(%%)helpPackage(mergeNSV) for the description;
 %put NOTE- ;
 %put NOTE- *** START ***; 

data _null_;
 length lazyData $ 32767; lazyData = lowcase(symget("lazyData"));
run;
%put NOTE- ;
%put NOTE: Data for package mergeNSV, version 1.0.0, license MIT;
%put NOTE- *** END ***;

/* lazydata.sas end */

